=====================================
 Event Snapshots - djcelery.snapshot
=====================================

.. contents::
    :local:
.. currentmodule:: djcelery.snapshot

.. automodule:: djcelery.snapshot
    :members:
    :undoc-members:
