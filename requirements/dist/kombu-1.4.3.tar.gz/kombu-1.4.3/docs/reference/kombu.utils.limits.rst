==========================================================
 Rate limiting - kombu.utils.limits
==========================================================

.. contents::
    :local:
.. currentmodule:: kombu.utils.limits

.. automodule:: kombu.utils.limits
    :members:
    :undoc-members:
