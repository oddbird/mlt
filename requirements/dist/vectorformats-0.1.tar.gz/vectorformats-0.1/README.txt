This is a library for easy serialization and deserialization of geographic
features (geometries and properties) into various formats.

For more, see the doc/ subdirectory.
