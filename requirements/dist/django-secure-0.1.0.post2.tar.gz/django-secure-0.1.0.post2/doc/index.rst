.. include:: ../README.rst
   :end-before: end-here

The Details
===========

.. toctree::
   :maxdepth: 2

   philosophy
   middleware
   checksecure
   settings
   changelog
   todo
   credits

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

